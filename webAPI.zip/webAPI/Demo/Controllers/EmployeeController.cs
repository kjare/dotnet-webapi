using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;


using Model1;
using Model2;

using DB;

namespace Controllers;

[ApiController]
[Route("api/[controller]")]
public class EmployeeController : ControllerBase
{
    private readonly ILogger<EmployeeController> _logger;

    public EmployeeController(ILogger<EmployeeController> logger)
    {
        _logger = logger;
    }
    [HttpGet]
    [Route("GetAllEmployees")]
    public Response GetAllEmployees()
    {
        Response response = new Response();
        DBManager db = new DBManager();
        response = db.GetAllEmployees();
        return response;

    }

    [HttpGet]
    [Route("GetEmployeeById/{id}")]
    public Response GetEmployeeById(int Id)
    {
        Response response = new Response();
        DBManager db = new DBManager();
        response = db.GetEmployeeById(Id);
        return response;

    }

    [HttpPost]
    [Route("AddEmployee")]
    public Response AddEmployee(Employee employee)
    {
        Response response = new Response();
        DBManager db = new DBManager();
        response = db.AddEmployee(employee);
        return response;

    }

    [HttpPut]
    [Route("UpdateEmployeeById")]
    public Response UpdateEmployeeById(Employee employee)
    {
        Response response = new Response();
        DBManager db = new DBManager();
        response = db.UpdateEmployeeById(employee);
        return response;

    }
    [HttpDelete]
    [Route("DeleteEmployeeById/{id}")]
    public Response DeleteEmployeeById(int Id)
    {
        Response response = new Response();
        DBManager db = new DBManager();
        response = db.DeleteEmployeeById(Id);
        return response;

    }


    
}