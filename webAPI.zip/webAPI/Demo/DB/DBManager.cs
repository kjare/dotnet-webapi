﻿namespace DB;
using MySql.Data.MySqlClient;
using Model1;
using System.Data;
using System;

using Model2;
public class DBManager
{
    public static string conString = @"server=localhost;port=3306;user=root; password=Admin@000;database=db1";

    public Response GetAllEmployees()
    {

        Response response = new Response();
        // SqlDataAdapter da = new SqlDataAdapter("Select * from Employees", connection);
        DataTable dt = new DataTable();

        List<Employee> lstEmployees = new List<Employee>();
        MySqlConnection con = new MySqlConnection();
        con.ConnectionString=conString;
    
        try
        {
            // DataSet ds=new DataSet();  //empty data set
            MySqlCommand cmd=new MySqlCommand();
            cmd.Connection=con;
            string query="SELECT * FROM Employees";
            cmd.CommandText=query;
            //disconnected Data Access logic
            MySqlDataAdapter da=new MySqlDataAdapter();
            da.SelectCommand = cmd;
            // DataTable dt=ds.Tables[0];
            da.Fill(dt);

            if( dt.Rows.Count > 0)
            {
                for(int i=0;i<dt.Rows.Count;i++)
                {
                    Employee employee = new Employee();
                    employee.Id = Convert.ToInt32(dt.Rows[i]["Id"]);
                    employee.Name = Convert.ToString(dt.Rows[i]["Name"]);
                    employee.Email = Convert.ToString(dt.Rows[i]["Email"]);
                    employee.IsActive = Convert.ToInt32(dt.Rows[i]["IsActive"]);
                    lstEmployees.Add(employee);
                }

            }
            if(lstEmployees.Count>0)
            {
                response.StatusCode = 200;
                response.StatusMessage = "Data found";
                response.listEmployee = lstEmployees;
            }
            else
            {
                response.StatusCode = 100;
                response.StatusMessage = "No Data found";
                response.listEmployee = null;
            }

    }
    catch(Exception ee)
    {
        Console.WriteLine(ee.Message);
    }

    return response;

    }

    public Response GetEmployeeById(int Id)
    {
        Response response = new Response();
        DataTable dt = new DataTable();
        Employee Employees = new Employee();
        MySqlConnection con = new MySqlConnection();
        con.ConnectionString=conString;
    
        try
        {
            // DataSet ds=new DataSet();  //empty data set
            MySqlCommand cmd=new MySqlCommand();
            cmd.Connection=con;
            string query="SELECT * FROM EMPLOYEES WHERE Id ='"+Id+"' AND IsActive=1 ";
            cmd.CommandText=query;
            //disconnected Data Access logic
            MySqlDataAdapter da=new MySqlDataAdapter();
            da.SelectCommand = cmd;
            // DataTable dt=ds.Tables[0];
            da.Fill(dt);

            if( dt.Rows.Count > 0)
            {
                
                Employee employee = new Employee();
                employee.Id = Convert.ToInt32(dt.Rows[0]["Id"]);
                employee.Name = Convert.ToString(dt.Rows[0]["Name"]);
                employee.Email = Convert.ToString(dt.Rows[0]["Email"]);
                employee.IsActive = Convert.ToInt32(dt.Rows[0]["IsActive"]);
            
                response.StatusCode = 200;
                response.StatusMessage = "Data found";
                response.Employee = employee;
            }
            else
            {
                response.StatusCode = 100;
                response.StatusMessage = "No Data found";
                response.Employee = null;
            }

    }
    catch(Exception ee)
    {
        Console.WriteLine(ee.Message);
    }

    return response;

    }

    public Response AddEmployee(Employee employee)
    {
        Response response = new Response();
        Employee Employees = new Employee();
        string query = "INSERT INTO Employees(Name,Email,IsActive,CreatedOn)" +
                            "VALUES('" + employee.Name + "','" + employee.Email + "','" + employee.IsActive + "',GetDate())";

        MySqlConnection con = new MySqlConnection();
        con.ConnectionString = conString;
        try{
            con.Open();
            MySqlCommand command = new MySqlCommand(query, con);
            int i=command.ExecuteNonQuery();  //DML
        

            if(i>0)
            {
                response.StatusCode = 200;
                response.StatusMessage = "Employee Added Successfully";
                response.Employee = employee;
            }
            else
            {
                response.StatusCode = 100;
                response.StatusMessage = "No Data Inserted";
                response.Employee = null;
            }

    }
    catch(Exception ee)
    {
        Console.WriteLine(ee.Message);
    }
    finally
    {
        con.Close();
    }  
    return response;

    }

    public Response UpdateEmployeeById(Employee employee )
    {
        Response response = new Response();
        Employee Employees = new Employee();
        string query = "UPDATE Employees SET Name = '" + employee.Name + "',Email='" +employee.Email + "' WHERE ID = '"+employee.Id+"')";

        MySqlConnection con = new MySqlConnection();
        con.ConnectionString = conString;
        try{
            con.Open();
            MySqlCommand command = new MySqlCommand(query, con);
            int i=command.ExecuteNonQuery();  //DML
        

            if(i>0)
            {
                response.StatusCode = 200;
                response.StatusMessage = "Employee Updated Successfully";
                response.Employee = employee;
            }
            else
            {
                response.StatusCode = 100;
                response.StatusMessage = "No Data Updated";
                response.Employee = null;
            }

    }
    catch(Exception ee)
    {
        Console.WriteLine(ee.Message);
    }
    finally
    {
        con.Close();
    }  
    return response;

    }

    public Response DeleteEmployeeById(int Id)
    {
        Response response = new Response();
        // Employee Employees = new Employee();
        string query = "DELETE FROM Employees WHERE Id= '"+Id+"')";

        MySqlConnection con = new MySqlConnection();
        con.ConnectionString = conString;
        try{
            con.Open();
            MySqlCommand command = new MySqlCommand(query, con);
            int i=command.ExecuteNonQuery();  //DML
        

            if(i>0)
            {
                response.StatusCode = 200;
                response.StatusMessage = "Employee Deleted Successfully";
                // response.Employee = employee;
            }
            else
            {
                response.StatusCode = 100;
                response.StatusMessage = "No Data Deleted";
                // response.Employee = null;
            }

    }
    catch(Exception ee)
    {
        Console.WriteLine(ee.Message);
    }
    finally
    {
        con.Close();
    }  
    return response;

    }
    

}
