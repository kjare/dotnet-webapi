using System.ComponentModel.DataAnnotations;
namespace Model1;

public class Employee
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Email { get; set; }
    public int IsActive { get; set; }
    

} 


// namespace DAL;
// using System.Data.SqlClient;
// using Models.Employee;

// public class DBManager
// {
//     public static string conString = @"server=localhost;port=3306;user=root; password=Admin@000;database=db1";

//     public Response GetAllEmployees()
//     {

//         Response response = new Response();
//         // SqlDataAdapter da = new SqlDataAdapter("Select * from Employees", connection);
//         // DataTable dt = new DataTable;

//         List<Employee> lstEmployees = new List<Employee>();
//         MySqlConnection con = new MySqlConnection();
//         con.ConnectionString=conString;
    
//         try
//         {
//             DataSet ds=new DataSet();  //empty data set
//             MySqlCommand cmd=new MySqlCommand();
//             cmd.Connection=con;
//             string query="SELECT * FROM Employees";
//             cmd.CommandText=query;
//             //disconnected Data Access logic
//             MySqlDataAdapter da=new MySqlDataAdapter();
//             da.SelectCommand = cmd;

//             da.Fill(dt);
//             if(dt.Rows.Count>0)
//             {
//                 for(int i=0;i<dt.Rows.Count;i++)
//                 {
//                     Employee employee = new Employee();
//                     employee.Id = convert.ToInt32(dt.Rows[i]["Id"]);
//                     employee.Name = convert.ToString(dt.Rows[i]["Name"]);
//                     employee.Email = convert.ToString(dt.Rows[i]["Email"]);
//                     employee.Id = convert.ToInt32(dt.Rows[i]["Id"]);
//                     lstEmployees.Add(employee);
//                 }

//             }
//             if(lstEmployees.Count>0)
//             {
//                 response.StatusCode = 200;
//                 response.StatusMessage = "Data found";
//                 response.listEmployee = lstEmployees;
//             }
//             else
//             {
//                 response.StatusCode = 100;
//                 response.StatusMessage = "No Data found";
//                 response.listEmployee = null;
//             }

//     }
//     catch(Exception ee)
//     {
//         Console.WriteLine(ee.Message);
//     }

//     return response;

//     }
// }
